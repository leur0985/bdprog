﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;





namespace BDPROG_CSharp
{
    class classExcel
    {
        public int columnas;
        DataTable dt;
        Microsoft.Office.Interop.Excel.Application oXL;
        Microsoft.Office.Interop.Excel._Worksheet oSheet;
        Microsoft.Office.Interop.Excel.Range oRng;
        

        public classExcel(int columnas, DataTable dt)
        {
            this.columnas = columnas;
            this.dt = new DataTable();
            this.dt = dt;
        }
        public void crearexcel()
        {

            oXL = new Microsoft.Office.Interop.Excel.Application();
            oXL.Visible = true;
            //Creamos un nuevo libro de Excel
            oXL.Workbooks.Add();
            oSheet = (Microsoft.Office.Interop.Excel._Worksheet)oXL.ActiveSheet;
            //Le asignamos a la hoja 1 el nombre de "Datos"
            oSheet.Name = "Datos";
            //Pegamos el contenido
            oSheet.get_Range(oSheet.Cells[1, 1], oSheet.Cells[1, 1]).Select();
            oXL.ActiveCell.PasteSpecial();
            oSheet.get_Range(oSheet.Cells[1, 1], oSheet.Cells[1, 1]).EntireColumn.Delete();

            ////Creamos los encabezados                                       
            for (int z = 0; z <= columnas; z++)
            {
                oSheet.Cells[1, z + 1] = Convert.ToString(dt.Columns[z].ColumnName);

                //  oSheet.get_Range("A1", "D1").Font.Bold = true;
                oSheet.get_Range(oSheet.Cells[1, z + 1], oSheet.Cells[1, z + 1]).Font.ColorIndex = 2;
                oSheet.get_Range(oSheet.Cells[1, z + 1], oSheet.Cells[1, z + 1]).Interior.ColorIndex = 5;
                oSheet.get_Range(oSheet.Cells[1, z + 1], oSheet.Cells[1, z + 1]).Font.Bold = true;
                oSheet.get_Range(oSheet.Cells[1, z + 1], oSheet.Cells[1, z + 1]).Font.Italic = true;
                oSheet.get_Range(oSheet.Cells[1, z + 1], oSheet.Cells[1, z + 1]).VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                // oRng = (oSheet.Cells[1, z], oSheet.Cells[1, z]);
                oRng = oSheet.get_Range(oSheet.Cells[1, z + 1], oSheet.Cells[1, z + 1]);
                oRng.EntireColumn.AutoFit();

            }






        }
    }
}
