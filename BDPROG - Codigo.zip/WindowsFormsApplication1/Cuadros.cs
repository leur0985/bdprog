﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace BDPROG_CSharp
{
    class Cuadros
    {
        OpenFileDialog f;
        SaveFileDialog guardar;
        public string archivo(string filtro, string titulo)
        {
            String archivo="Hola";
            f = new OpenFileDialog();
            f.Filter = filtro;
            if (f.ShowDialog()==DialogResult.OK){
                archivo = f.FileName;
            }
            return archivo;


        }
        public string directorio(string filtro, string titulo)
        {
            String archivo = "Hola";
            String dir;
            f = new OpenFileDialog();
            f.Filter = filtro;
            if (f.ShowDialog() == DialogResult.OK)
            {
              archivo = f.FileName;
              dir = System.IO.Path.GetDirectoryName(archivo);
              archivo = dir;
            }
            return archivo;


        }
        public string guarda(string filtro, string titulo)
        {
            String archivo = "Hola";
            guardar = new SaveFileDialog();
            guardar.Filter = filtro;
            if (guardar.ShowDialog() == DialogResult.OK)
            {
                archivo = guardar.FileName;
               
            }
            return archivo;


        }
    }
}
