﻿/*'Ultima modificación 20 de Octubre 2010. Se agregó opción para conectar con Access 2007'
'Se corrigió el error al contar ls registros, ya que contaba el número total -1        '
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

' 08-Marzo-2011. Se cambio el ODBC de SQL Server por SQLConection, para que puediera funcionar 

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'No recuerdo la fecha, pero se agrego SQL-Lite como nuevo gestor de BD

'
''27-May0-2011, se agrega la opción de abrir bases de datos con contraseña de Access (HASTA LAS 8:35 TENGO CON ACCESS 2003)
''' <summary>
''' 
''' </summary>
''
 *03-03-2014, se agrega la opción para abrir postgres */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Xml;
using PasoExcel;
using System.Threading;
using WindowsFormsApplication1;





//using ClassLibrary2;


namespace BDPROG_CSharp
{
    public partial class Form1 : Form
    {
        
        Cuadros examinar;
        conexion con;
        String usermysql;
        String passmysql;
        String usersql;
        String passsql;
        DateTime fecha = DateTime.Now;
        int totalregistros;
        public DataTable dt=new DataTable();
        SqlDataSourceEnumerator servidores;
        //string[] ReservadasBlue = { "if", "then", "else" };
        
        
        public Form1()
        {

            Thread th = new Thread(new ThreadStart(DoSplash));
            th.Start();
            Thread.Sleep(3000);
            th.Abort();
            Thread.Sleep(1000);
            InitializeComponent();
            
            
        }
        public void DoSplash()
        {
            Splash sp = new Splash();
            sp.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Application.DoEvents();

            this.Location = new Point(85, 20);
            timer1.Enabled = true;
            timer1.Start();
            

            
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Application.DoEvents();
    
                       
            lbhora.Text = DateTime.Now.ToString("hh:mm:ss tt");




            lbfecha.Text = string.Format(DateTime.Now.ToString("dddd dd {0} MMMM {0} yyyy"), "de");
            //--------------------
            

         
            
        }
        
       

        private void btExaminar_Click(object sender, EventArgs e)
        {
            examinar = new Cuadros();
            String filtro="";
            String titulo="";
            if (cbGestores.Text == "MS Access")
            {
               
                filtro = "Archivo de Access (*.mdb)|*.mdb, *.accdb|Archivo de Access 2007-adelante (*.accdb)|*.accdb";
                titulo = "Archivos de Access";
                txtRuta.Text = examinar.archivo(filtro, titulo);
            }
            if (cbGestores.Text == "Firebird")
            {

                filtro = "Archivo de Firebird (*.fdb)|*.fdb";
                titulo = "Archivos de Firebird";
                txtRuta.Text = examinar.archivo(filtro, titulo);
            }
            if (cbGestores.Text == "Fox Pro Base de Datos")
            {
                filtro = "Archivo de Base de Datos (*.dbc)|*.dbc";
                titulo = "Archivos de Base de Datos Fox";
                txtRuta.Text = examinar.archivo(filtro, titulo);
            }
            if (cbGestores.Text == "Fox Pro Tabla Libre")
            {
                filtro = "Archivo de Base de Datos (*.dbf)|*.dbf";
                titulo = "Archivos de Base de Datos Fox";
                txtRuta.Text = examinar.directorio(filtro, titulo);
            }
            if (cbGestores.Text == "Paradox")
            {
                filtro = "Archivo de Base de Datos (*.db)|*.db";
                titulo = "Archivos de Base de Datos Paradox";
                txtRuta.Text = examinar.directorio(filtro, titulo);
            }
            if (cbGestores.Text == "Excel")
            {
                filtro = "Archivo de Base de Datos (*.xlsx)|*.xlsx|Archivo de base de Datos de Excel 97 (*.xls)|*.xls";
                titulo = "Archivos de Base de Datos Excel";
                txtRuta.Text = examinar.archivo(filtro, titulo);
            }
            if (cbGestores.Text == "Sqlite")
            {
                filtro = "Archivo de Base de Datos (*.db)|*.db";
                titulo = "Archivos de Base de Datos";
                txtRuta.Text = examinar.archivo(filtro, titulo);
                
            }
            if (cbGestores.Text == "CSV")
            {
                String archivo;
                Cuadros cuadros = new Cuadros();
                archivo = cuadros.archivo("Archivo CSV (*.csv)|*.csv, *.txt|Archivo TXT(*.txt)|*.txt", "Selecciona archivo");
                txtRuta.Text = archivo;
            }
            if (cbGestores.Text == "XML")
            {
                XmlDataDocument xmldata = new XmlDataDocument();
                String archivo;
                Cuadros cuadros = new Cuadros();
                archivo = cuadros.archivo("Archivo XML (*.xml)|*.xml", "Selecciona archivo");
                lbXML.Text = archivo;
                txtRuta.Text = archivo;
                lbXML.Visible = true;
                lbTablas.Visible = true;
                cbTablas.Visible = true;
                xmldata.DataSet.ReadXml(txtRuta.Text);
               
                for (int i = 0; i <= xmldata.DataSet.Tables.Count - 1; i++)
                {

                    cbTablas.Items.Add(Convert.ToString(xmldata.DataSet.Tables[i].TableName));
                }
               
              

            }
           
           
            
            
        }

        private void btSQL_Click(object sender, EventArgs e)
        {
            if (cbGestores.Text != "" && txtRuta.Text != "" && txtComando.Text != "")
            {
                switch (cbGestores.Text)
                {

                    case "MS Access":

                        con = new conexion("Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + txtRuta.Text + "';Jet OLEDB:Database Password=;");
                        llenarole();
                        break;
                    case "Fox Pro Base de Datos":
                        con = new conexion("Provider=vfpoledb;Data Source='" + txtRuta.Text + "';Collating Sequence=machine;");
                        llenarole();
                        break;
                    case "Fox Pro Tabla Libre":
                        con = new conexion("Provider=vfpoledb;Data Source='" + txtRuta.Text + "';Collating Sequence=general;");
                        llenarole();
                        break;
                    case "Firebird":
                        con = new conexion("DRIVER=Firebird/InterBase(r) driver;UID=SYSDBA;PWD=masterkey;DBNAME='" + txtRuta.Text + "';READONLY=YES;");
                        llenarodbc();
                        break;
                    case "MySql":
                        con = new conexion("Server='" + txtServidor.Text + "';Database='" + txtRuta.Text + "';Uid='" + usermysql + "';Pwd='" + passmysql + "';");
                        llenarmysql();
                        break;
                    case "PostgreSQL":
                        con = new conexion("Server='" + txtServidor.Text + "';Port=5432;Database='" + txtRuta.Text + "';User Id='" + usermysql + "';Password='" + passmysql + "';");
                        llenarpos();
                        break;
                    case "Paradox":
                        con = new conexion("Provider=Microsoft.Jet.OLEDB.4.0;Data Source='" + txtRuta.Text + "';Extended Properties=Paradox 5.x;");
                        llenarole();
                        break;
                    case "Excel":
                        con = new conexion("Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + txtRuta.Text + "';Extended Properties='Excel 12.0 Xml;HDR=YES';");
                        llenarole();
                        break;
                    case "Microsoft SQL Server":
                        if (rbWin.Checked == true)
                        {
                            con = new conexion("Server='" + cbInstancia.Text + "';Database='" + cbBasesSQL.Text + "';Trusted_Connection=True;");
                            llenarsql();
                        }
                        if (rbSQL.Checked == true)
                        {
                            con = new conexion("Server=" + cbInstancia.Text + ";Database=" + cbBasesSQL.Text + ";User Id=" + usersql + ";Password=" + passsql + " ;");
                            llenarsql();
                        }
                        break;
                    case "Sqlite":
                        con = new conexion("Data Source='" + txtRuta.Text + "'");
                        llenarsqlite();
                        break;

                    case "CSV":
                        con = new conexion("Provider=Microsoft.Jet.OLEDB.4.0;Data Source='" + txtRuta.Text + "'Extended Properties='TEXT;'");
                        llenarcsv();
                        break;

                    case "XML":
                        llenarxml();
                        break;
            
                }
                totalregistros = this.dataGridView1.Rows.Count - 1;
                lbTotalRegistros.Text = Convert.ToString(totalregistros);
            }
            else
            {
                MessageBox.Show("No se encuentra ningún párametro para la consulta", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          
            
        }
            private void llenarcsv()
            {
                dt = con.consultaole(txtComando.Text);
                this.dataGridView1.DataSource = dt;
            }
            private void llenarxml()
            {
                XmlDataDocument xmldata = new XmlDataDocument();
                xmldata.DataSet.ReadXml(txtRuta.Text);
                this.dataGridView1.DataSource = xmldata.DataSet;
                this.dataGridView1.DataMember = cbTablas.Text ;
               
            }
            private void llenarole(){
                try
                {
                    if (con.conectarole())
                    {

                        dt = con.consultaole(txtComando.Text);
                        this.dataGridView1.DataSource = dt;
                    }
                    else
                    {
                        MessageBox.Show(con.error);
                    }

                }
                catch (NullReferenceException)
                {
                    MessageBox.Show("No se puede realizr una consulta sin un comando o si una base de datos seleccionada", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            
           
        }
            private void llenarodbc()
            {
               
                    if (con.conectarodbc())
                    {

                        dt = con.consultaodbc(txtComando.Text);
                        this.dataGridView1.DataSource = dt;
                    }
                    else
                    {
                        MessageBox.Show(con.error);
                    }

                
    
               
            }
            private void llenarsql()
            {
                try
                {
                    if (con.conectarsql())
                    {
                        dt = con.consultasql(txtComando.Text);
                        this.dataGridView1.DataSource = dt;
                    }
                    else
                    {
                        MessageBox.Show(con.error);
                    }


                }
                catch (NullReferenceException)
                {
                    MessageBox.Show("No se puede realizr una consulta sin un comando o si una base de datos seleccionada", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }



            }
            private void llenarmysql()
            {
                try
                {
                    dt = con.consultamysql(txtComando.Text);
                    this.dataGridView1.DataSource = dt;
                   
                }
                catch (NullReferenceException)
                {
                    MessageBox.Show("No se puede realizr una consulta sin un comando o si una base de datos seleccionada", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }


            }
        //-------------------
            private void llenarpos()
            {
                try
                {
                    dt = con.consultapos(txtComando.Text);
                    this.dataGridView1.DataSource = dt;

                }
                catch (NullReferenceException)
                {
                    MessageBox.Show("No se puede realizr una consulta sin un comando o si una base de datos seleccionada", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


            }

            private void llenarsqlite()
            {
                try
                {
                    dt = con.consultasqlite(txtComando.Text);
                    this.dataGridView1.DataSource = dt;
                    
                }
                catch (NullReferenceException)
                {
                    MessageBox.Show("No se puede realizr una consulta sin un comando o si una base de datos seleccionada", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }


            }

        private void cbGestores_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbGestores.Text == "MySql" || cbGestores.Text=="PostgreSQL")
            {
                cbBasesSQL.Visible = false;
                lbServidor.Visible = true;
                txtServidor.Visible = true;
                cbInstancia.Visible = false;
                lbXML.Visible = false;
                usermysql = Inputbox.Show("Usuario", "Ingresa el Usuario", FormStartPosition.CenterParent);
                passmysql = Inputbox.Show("Password", "Ingresa la contraseña", FormStartPosition.CenterParent);

            }
            else
            {
                lbServidor.Visible = false;
                txtServidor.Visible = false;
                cbInstancia.Visible = false;
                cbBasesSQL.Visible = false;
            }
            if (cbGestores.Text == "Microsoft SQL Server")
            {
                lbServidor.Visible = true;
                cbBasesSQL.Visible = true;
                gbAut.Visible = true;
                cbInstancia.Visible = true;
                
                llenarinstancias();
            }
            if (cbGestores.Text == "CSV")
            {
                 
                 String archivo;
                Cuadros cuadros = new Cuadros();
                archivo = cuadros.archivo("Archivo CSV (*.csv)|*.csv, *.txt|Archivo TXT(*.txt)|*.txt","Selecciona archivo");
                txtRuta.Text = archivo;
            }
            if (cbGestores.Text == "XML")
            {
                XmlDataDocument xmldata = new XmlDataDocument();
                String archivo;
                Cuadros cuadros = new Cuadros();
                archivo = cuadros.archivo("Archivo XML (*.xml)|*.xml","Selecciona archivo");
                lbXML.Text = archivo;
                txtRuta.Text = archivo;
                lbXML.Visible = true;
                lbTablas.Visible = true;
                cbTablas.Visible = true;
                xmldata.DataSet.ReadXml(txtRuta.Text);
                cbTablas.Items.Clear();
                for (int i = 0; i <= xmldata.DataSet.Tables.Count - 1; i++)
                {

                    cbTablas.Items.Add(Convert.ToString(xmldata.DataSet.Tables[i].TableName));
                }
            }
            else
            {
                lbXML.Visible = false;
                lbTablas.Visible = false;
                cbTablas.Visible = false ;
            }

        }

        private void cbInstancia_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        void llenarinstancias()
        {

            cbInstancia.Items.Clear();
            DataTable dt = new DataTable();
            int instancias;
            servidores = SqlDataSourceEnumerator.Instance;
            dt = servidores.GetDataSources();
            instancias = dt.Rows.Count;
            foreach (DataRow servSQL in dt.Rows)
            {
                cbInstancia.Items.Add(servSQL["ServerName"] + "\\" + servSQL["InstanceName"]);
                
                
            }
            
        }
        void llenarbases()
        {
            if (con.conectarsql())
            {
                try
                {
                    DataTable bases = new DataTable();
                  
                        bases = con.consultasql("sp_databases");
                  
                    cbBasesSQL.DataSource = bases;
                    cbBasesSQL.ValueMember = Convert.ToString(bases.Columns[0]);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(con.error);
            }
            
        }

        private void btExcel_Click(object sender, EventArgs e)
        {
            exporta_a_excel();
        }
        public void exporta_a_excel()
        {
            int columnas = this.dataGridView1.Columns.Count-1;
            int registros = dt.Rows.Count-1;
            this.dataGridView1.SelectAll();
            
        //Si hay algun dato en el DataGrid entonces lo copiamos
            if (this.dataGridView1.GetCellCount(DataGridViewElementStates.Selected) > 0)
            {
                PasoExcel.cnvExcel ex = new cnvExcel(columnas, dt);
                Clipboard.SetDataObject(this.dataGridView1.GetClipboardContent());
                ex.crearexcel();
                          
            }
        }

        private void rbWin_CheckedChanged(object sender, EventArgs e)
        {
            cbInstancia.Enabled = true;
        }

        private void rbSQL_CheckedChanged(object sender, EventArgs e)
        {
            cbInstancia.Enabled = true;
            
        }

        private void btcsv_Click(object sender, EventArgs e)
        {
            if (txtComando.Text != "")
            {
                FormCsv formacsv = new FormCsv();
                formacsv.tabla = dt;
                formacsv.ShowDialog();
            }
            else
            {
                MessageBox.Show("No se ha hecho ninguna consulta", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btXML_Click(object sender, EventArgs e)
        {
            FormXML creaxml = new FormXML();
            creaxml.dt = dt;
            creaxml.ShowDialog();
        }

          private void cbBasesSQL_Click(object sender, EventArgs e)
        {
            if (cbGestores.Text == "Microsoft SQL Server" && rbWin.Checked == true)
            {
                con = new conexion("Server='" + cbInstancia.Text + "';Database=master;Trusted_Connection=True;");
                llenarbases();
            }
            if (cbGestores.Text == "Microsoft SQL Server" && rbSQL.Checked == true)
            {
               // MessageBox.Show("Server=" + cbInstancia.Text + ";Database=master;User Id=" + usersql + ";Password=" + passsql + " ;");
                 con = new conexion("Server=" + cbInstancia.Text + ";Database=master;User Id=" + usersql + ";Password=" + passsql + " ;");
                llenarbases();
            }
        }

     

          private void rbSQL_Click(object sender, EventArgs e)
          {
              usersql = Inputbox.Show("Usuario", "Ingresa el Usuario", FormStartPosition.CenterParent);
              passsql = Inputbox.Show("Password", "Ingresa la contraseña", FormStartPosition.CenterParent);
          }

          private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
          {

          }

          private void cbBasesSQL_SelectedIndexChanged(object sender, EventArgs e)
          {
              txtRuta.Text = cbBasesSQL.Text;
          }

          private void txtComando_Enter(object sender, EventArgs e)
          {
              if (txtComando.Text == "INGRESE EL COMANDO SQL AQUÍ...")
              {
                  txtComando.Text = "";
              }

          }

          //private void txtComando_TextChanged(object sender, EventArgs e)
          //{
              
          //    txtComando.Find("select");
          //    txtComando.SelectionColor = Color.Green;
          //    txtComando.Select(txtComando.Text.Length,0);

          //    txtComando.SelectionColor = Color.Black;

          //}

          
    }
}