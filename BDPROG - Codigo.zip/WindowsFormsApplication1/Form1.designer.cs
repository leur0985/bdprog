﻿namespace BDPROG_CSharp
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbhora = new System.Windows.Forms.Label();
            this.lbfecha = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbTotalRegistros = new System.Windows.Forms.Label();
            this.btSQL = new System.Windows.Forms.Button();
            this.lbTipoBase = new System.Windows.Forms.Label();
            this.cbGestores = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.btExaminar = new System.Windows.Forms.Button();
            this.lbServidor = new System.Windows.Forms.Label();
            this.txtServidor = new System.Windows.Forms.TextBox();
            this.cbInstancia = new System.Windows.Forms.ComboBox();
            this.gbAut = new System.Windows.Forms.GroupBox();
            this.rbSQL = new System.Windows.Forms.RadioButton();
            this.rbWin = new System.Windows.Forms.RadioButton();
            this.cbBasesSQL = new System.Windows.Forms.ComboBox();
            this.btExcel = new System.Windows.Forms.Button();
            this.btcsv = new System.Windows.Forms.Button();
            this.btXML = new System.Windows.Forms.Button();
            this.lbXML = new System.Windows.Forms.Label();
            this.cbTablas = new System.Windows.Forms.ComboBox();
            this.lbTablas = new System.Windows.Forms.Label();
            this.txtComando = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.gbAut.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbhora
            // 
            this.lbhora.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbhora.AutoSize = true;
            this.lbhora.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbhora.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbhora.Location = new System.Drawing.Point(1110, 19);
            this.lbhora.Name = "lbhora";
            this.lbhora.Size = new System.Drawing.Size(53, 18);
            this.lbhora.TabIndex = 1;
            this.lbhora.Text = "lbHora";
            // 
            // lbfecha
            // 
            this.lbfecha.AutoSize = true;
            this.lbfecha.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbfecha.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbfecha.Location = new System.Drawing.Point(12, 19);
            this.lbfecha.Name = "lbfecha";
            this.lbfecha.Size = new System.Drawing.Size(60, 18);
            this.lbfecha.TabIndex = 2;
            this.lbfecha.Text = "lbFecha";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(23, 49);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1166, 319);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lbTotalRegistros
            // 
            this.lbTotalRegistros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTotalRegistros.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalRegistros.ForeColor = System.Drawing.Color.Blue;
            this.lbTotalRegistros.Location = new System.Drawing.Point(1129, 383);
            this.lbTotalRegistros.Name = "lbTotalRegistros";
            this.lbTotalRegistros.Size = new System.Drawing.Size(79, 19);
            this.lbTotalRegistros.TabIndex = 4;
            // 
            // btSQL
            // 
            this.btSQL.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.btSQL.AutoEllipsis = true;
            this.btSQL.BackColor = System.Drawing.Color.Lavender;
            this.btSQL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btSQL.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.btSQL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btSQL.FlatAppearance.BorderSize = 2;
            this.btSQL.Font = new System.Drawing.Font("Kristen ITC", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSQL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btSQL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btSQL.Location = new System.Drawing.Point(999, 488);
            this.btSQL.Name = "btSQL";
            this.btSQL.Size = new System.Drawing.Size(58, 59);
            this.btSQL.TabIndex = 7;
            this.btSQL.Text = "&SQL";
            this.btSQL.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btSQL.UseCompatibleTextRendering = true;
            this.btSQL.UseVisualStyleBackColor = false;
            this.btSQL.UseWaitCursor = true;
            this.btSQL.Click += new System.EventHandler(this.btSQL_Click);
            // 
            // lbTipoBase
            // 
            this.lbTipoBase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTipoBase.AutoEllipsis = true;
            this.lbTipoBase.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbTipoBase.Location = new System.Drawing.Point(842, 383);
            this.lbTipoBase.Name = "lbTipoBase";
            this.lbTipoBase.Size = new System.Drawing.Size(100, 34);
            this.lbTipoBase.TabIndex = 8;
            this.lbTipoBase.Text = "¿Que base de datos vas a usar?";
            // 
            // cbGestores
            // 
            this.cbGestores.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbGestores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbGestores.FormattingEnabled = true;
            this.cbGestores.Items.AddRange(new object[] {
            "Fox Pro Tabla Libre",
            "Fox Pro Base de Datos",
            "MS Access",
            "Paradox",
            "Excel",
            "MySql",
            "Microsoft SQL Server",
            "Sqlite",
            "CSV",
            "Firebird",
            "PostgreSQL",
            "XML"});
            this.cbGestores.Location = new System.Drawing.Point(937, 383);
            this.cbGestores.Name = "cbGestores";
            this.cbGestores.Size = new System.Drawing.Size(176, 26);
            this.cbGestores.TabIndex = 9;
            this.cbGestores.SelectedIndexChanged += new System.EventHandler(this.cbGestores_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(33, 424);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 40);
            this.label3.TabIndex = 10;
            this.label3.Text = "Seleccione directorio o archivo de base de datos";
            // 
            // txtRuta
            // 
            this.txtRuta.Location = new System.Drawing.Point(157, 447);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.Size = new System.Drawing.Size(171, 20);
            this.txtRuta.TabIndex = 11;
            // 
            // btExaminar
            // 
            this.btExaminar.AutoEllipsis = true;
            this.btExaminar.Location = new System.Drawing.Point(334, 447);
            this.btExaminar.Name = "btExaminar";
            this.btExaminar.Size = new System.Drawing.Size(52, 20);
            this.btExaminar.TabIndex = 12;
            this.btExaminar.Text = "...";
            this.btExaminar.UseVisualStyleBackColor = true;
            this.btExaminar.Click += new System.EventHandler(this.btExaminar_Click);
            // 
            // lbServidor
            // 
            this.lbServidor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbServidor.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbServidor.Location = new System.Drawing.Point(842, 417);
            this.lbServidor.Name = "lbServidor";
            this.lbServidor.Size = new System.Drawing.Size(83, 40);
            this.lbServidor.TabIndex = 13;
            this.lbServidor.Text = "¿Cual es el servidor?";
            this.lbServidor.Visible = false;
            // 
            // txtServidor
            // 
            this.txtServidor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServidor.Location = new System.Drawing.Point(937, 417);
            this.txtServidor.Name = "txtServidor";
            this.txtServidor.Size = new System.Drawing.Size(151, 20);
            this.txtServidor.TabIndex = 14;
            this.txtServidor.Visible = false;
            // 
            // cbInstancia
            // 
            this.cbInstancia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbInstancia.Enabled = false;
            this.cbInstancia.FormattingEnabled = true;
            this.cbInstancia.Location = new System.Drawing.Point(948, 417);
            this.cbInstancia.Name = "cbInstancia";
            this.cbInstancia.Size = new System.Drawing.Size(182, 21);
            this.cbInstancia.TabIndex = 15;
            this.cbInstancia.Visible = false;
            this.cbInstancia.SelectedIndexChanged += new System.EventHandler(this.cbInstancia_SelectedIndexChanged);
            // 
            // gbAut
            // 
            this.gbAut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gbAut.Controls.Add(this.rbSQL);
            this.gbAut.Controls.Add(this.rbWin);
            this.gbAut.Location = new System.Drawing.Point(659, 383);
            this.gbAut.Name = "gbAut";
            this.gbAut.Size = new System.Drawing.Size(177, 69);
            this.gbAut.TabIndex = 16;
            this.gbAut.TabStop = false;
            this.gbAut.Text = "Método de Autenticación";
            this.gbAut.Visible = false;
            // 
            // rbSQL
            // 
            this.rbSQL.AutoSize = true;
            this.rbSQL.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.rbSQL.Location = new System.Drawing.Point(6, 42);
            this.rbSQL.Name = "rbSQL";
            this.rbSQL.Size = new System.Drawing.Size(114, 17);
            this.rbSQL.TabIndex = 1;
            this.rbSQL.TabStop = true;
            this.rbSQL.Text = "Autenticación SQL";
            this.rbSQL.UseVisualStyleBackColor = true;
            this.rbSQL.CheckedChanged += new System.EventHandler(this.rbSQL_CheckedChanged);
            this.rbSQL.Click += new System.EventHandler(this.rbSQL_Click);
            // 
            // rbWin
            // 
            this.rbWin.AutoSize = true;
            this.rbWin.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.rbWin.Location = new System.Drawing.Point(6, 19);
            this.rbWin.Name = "rbWin";
            this.rbWin.Size = new System.Drawing.Size(137, 17);
            this.rbWin.TabIndex = 0;
            this.rbWin.TabStop = true;
            this.rbWin.Text = "Autenticación Windows";
            this.rbWin.UseVisualStyleBackColor = true;
            this.rbWin.CheckedChanged += new System.EventHandler(this.rbWin_CheckedChanged);
            // 
            // cbBasesSQL
            // 
            this.cbBasesSQL.FormattingEnabled = true;
            this.cbBasesSQL.Location = new System.Drawing.Point(157, 424);
            this.cbBasesSQL.Name = "cbBasesSQL";
            this.cbBasesSQL.Size = new System.Drawing.Size(151, 21);
            this.cbBasesSQL.TabIndex = 17;
            this.cbBasesSQL.Visible = false;
            this.cbBasesSQL.SelectedIndexChanged += new System.EventHandler(this.cbBasesSQL_SelectedIndexChanged);
            this.cbBasesSQL.Click += new System.EventHandler(this.cbBasesSQL_Click);
            // 
            // btExcel
            // 
            this.btExcel.BackColor = System.Drawing.Color.Khaki;
            this.btExcel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btExcel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btExcel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btExcel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btExcel.Location = new System.Drawing.Point(23, 374);
            this.btExcel.Name = "btExcel";
            this.btExcel.Size = new System.Drawing.Size(128, 28);
            this.btExcel.TabIndex = 18;
            this.btExcel.Text = "Exportar a Excel";
            this.btExcel.UseVisualStyleBackColor = false;
            this.btExcel.Click += new System.EventHandler(this.btExcel_Click);
            // 
            // btcsv
            // 
            this.btcsv.BackColor = System.Drawing.Color.Khaki;
            this.btcsv.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btcsv.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btcsv.Location = new System.Drawing.Point(157, 375);
            this.btcsv.Name = "btcsv";
            this.btcsv.Size = new System.Drawing.Size(128, 28);
            this.btcsv.TabIndex = 19;
            this.btcsv.Text = "Exportar a Csv";
            this.btcsv.UseVisualStyleBackColor = false;
            this.btcsv.Click += new System.EventHandler(this.btcsv_Click);
            // 
            // btXML
            // 
            this.btXML.BackColor = System.Drawing.Color.Khaki;
            this.btXML.Location = new System.Drawing.Point(291, 374);
            this.btXML.Name = "btXML";
            this.btXML.Size = new System.Drawing.Size(128, 28);
            this.btXML.TabIndex = 20;
            this.btXML.Text = "Exportar a XML";
            this.btXML.UseVisualStyleBackColor = false;
            this.btXML.Click += new System.EventHandler(this.btXML_Click);
            // 
            // lbXML
            // 
            this.lbXML.AutoSize = true;
            this.lbXML.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbXML.Location = new System.Drawing.Point(915, 407);
            this.lbXML.Name = "lbXML";
            this.lbXML.Size = new System.Drawing.Size(35, 13);
            this.lbXML.TabIndex = 21;
            this.lbXML.Text = "label1";
            this.lbXML.Visible = false;
            // 
            // cbTablas
            // 
            this.cbTablas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbTablas.FormattingEnabled = true;
            this.cbTablas.Location = new System.Drawing.Point(654, 385);
            this.cbTablas.Name = "cbTablas";
            this.cbTablas.Size = new System.Drawing.Size(151, 21);
            this.cbTablas.TabIndex = 23;
            this.cbTablas.Visible = false;
            // 
            // lbTablas
            // 
            this.lbTablas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTablas.AutoEllipsis = true;
            this.lbTablas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbTablas.Location = new System.Drawing.Point(559, 385);
            this.lbTablas.Name = "lbTablas";
            this.lbTablas.Size = new System.Drawing.Size(100, 34);
            this.lbTablas.TabIndex = 22;
            this.lbTablas.Text = "Tablas en el XML";
            this.lbTablas.Visible = false;
            // 
            // txtComando
            // 
            this.txtComando.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtComando.AutoWordSelection = true;
            this.txtComando.EnableAutoDragDrop = true;
            this.txtComando.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComando.Location = new System.Drawing.Point(38, 495);
            this.txtComando.Name = "txtComando";
            this.txtComando.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.txtComando.Size = new System.Drawing.Size(927, 115);
            this.txtComando.TabIndex = 25;
            this.txtComando.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(1208, 631);
            this.Controls.Add(this.txtComando);
            this.Controls.Add(this.cbTablas);
            this.Controls.Add(this.lbXML);
            this.Controls.Add(this.lbTablas);
            this.Controls.Add(this.btXML);
            this.Controls.Add(this.btcsv);
            this.Controls.Add(this.btExcel);
            this.Controls.Add(this.cbBasesSQL);
            this.Controls.Add(this.gbAut);
            this.Controls.Add(this.cbInstancia);
            this.Controls.Add(this.txtServidor);
            this.Controls.Add(this.lbServidor);
            this.Controls.Add(this.btExaminar);
            this.Controls.Add(this.txtRuta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbGestores);
            this.Controls.Add(this.lbTipoBase);
            this.Controls.Add(this.btSQL);
            this.Controls.Add(this.lbTotalRegistros);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lbfecha);
            this.Controls.Add(this.lbhora);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "BDPROG";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.gbAut.ResumeLayout(false);
            this.gbAut.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbhora;
        private System.Windows.Forms.Label lbfecha;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbTotalRegistros;
        private System.Windows.Forms.Button btSQL;
        private System.Windows.Forms.Label lbTipoBase;
        private System.Windows.Forms.ComboBox cbGestores;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRuta;
        private System.Windows.Forms.Button btExaminar;
        private System.Windows.Forms.Label lbServidor;
        private System.Windows.Forms.TextBox txtServidor;
        private System.Windows.Forms.ComboBox cbInstancia;
        private System.Windows.Forms.GroupBox gbAut;
        private System.Windows.Forms.RadioButton rbSQL;
        private System.Windows.Forms.RadioButton rbWin;
        private System.Windows.Forms.ComboBox cbBasesSQL;
        private System.Windows.Forms.Button btExcel;
        private System.Windows.Forms.Button btcsv;
        private System.Windows.Forms.Button btXML;
        private System.Windows.Forms.Label lbXML;
        private System.Windows.Forms.ComboBox cbTablas;
        private System.Windows.Forms.Label lbTablas;
        private System.Windows.Forms.RichTextBox txtComando;
    }
}

