﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.Sql;
using System.Data.SQLite;
using Npgsql;



namespace BDPROG_CSharp
{
    class conexion
    {
        string cadena;
        
        Boolean conectado = false;
        public string error;
        OleDbDataAdapter daole;
        OleDbConnection conole;
        OdbcConnection conodbc;
        OdbcDataAdapter daodbc;
        MySqlConnection conmysql;
        MySqlDataAdapter mysqlda;
        NpgsqlConnection poscon;
        NpgsqlDataAdapter posda;
        SqlConnection consql;
        SqlDataAdapter sqlda;
        SQLiteConnection sqlitecon;
        SQLiteDataAdapter sqliteda;

        public conexion(string cadena)
        {
            this.cadena = cadena;
        }
        public Boolean conectarole()
        {
            try
            {
                conole = new OleDbConnection(cadena);
                conectado = true;
            }
            catch (SystemException e)
            {
                conectado = false;
                error = e.Message;
            }
            return conectado;
        }
        public System.Data.DataTable consultaole(string comando)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            conectarole();
            try
            {
                daole = new OleDbDataAdapter(comando, conole);
                daole.Fill(dt);
            }
            catch (Exception e)
            {
                error = e.Message;
                System.Windows.Forms.MessageBox.Show(e.Message, "ERROR", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            return dt;
        }
        public Boolean conectarodbc()
        {
            try
            {
                conodbc = new OdbcConnection(cadena);
                conectado = true;
            }
            catch (SystemException e)
            {
                conectado = false;
                error = e.Message;
            }
            return conectado;
        }
        public System.Data.DataTable consultaodbc(string comando)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            conectarodbc();
            try
            {
                daodbc = new OdbcDataAdapter (comando, conodbc);
                daodbc.Fill(dt);
            }
            catch (Exception e)
            {
                error = e.Message;
                System.Windows.Forms.MessageBox.Show(e.Message, "ERROR", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            return dt;
        }

        public Boolean conectarmysql()
        {
            try
            {
                conmysql = new MySqlConnection(cadena);
                conectado = true;
            }
            catch (SystemException e)
            {
                conectado = false;
                error = e.Message;
            }
            return conectado;
        }
        //-----------
        public Boolean conectarposgress()
        {
            try
            {
                poscon = new NpgsqlConnection(cadena);
                conectado = true;
            }
            catch (SystemException e)
            {
                conectado = false;
                error = e.Message;
            }
            return conectado;
        }
        public DataTable consultamysql(string comando)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            conectarmysql();
           try
           {
                mysqlda = new MySqlDataAdapter(comando, conmysql);
                mysqlda.Fill(dt);
           }
           catch (Exception e)
           {
               System.Windows.Forms.MessageBox.Show(e.Message, "ERROR", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
           }
            return dt;
        }
        //----------
        public DataTable consultapos(string comando)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            conectarposgress();
            try
            {
                //mysqlda = new MySqlDataAdapter(comando, conmysql);
                posda = new NpgsqlDataAdapter(comando, poscon);
                posda.Fill(dt);
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message, "ERROR", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            return dt;
        }

        public Boolean conectarsql()
        {
            try
            {
                consql = new SqlConnection (cadena);
                conectado = true;
            }
            catch (SystemException e)
            {
                conectado = false;
                error = e.Message;
            }
            return conectado;
        }
        public DataTable consultasql(string comando)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            conectarsql();
            try
            {
                sqlda = new SqlDataAdapter (comando, consql);
                sqlda.Fill(dt);
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message, "ERROR", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            return dt;
        }
        public Boolean conectarsqlite()
        {
            try
            {
                sqlitecon = new  SQLiteConnection(cadena);
                conectado = true;
            }
            catch (SystemException e)
            {
                conectado = false;
                error = e.Message;
            }
            return conectado;
        }
        public DataTable consultasqlite(string comando)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            conectarsqlite();
            try
            {
            sqliteda = new SQLiteDataAdapter(comando, sqlitecon);
            sqliteda.Fill(dt);
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message, "ERROR", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            return dt;
        }
        
        
    }
}