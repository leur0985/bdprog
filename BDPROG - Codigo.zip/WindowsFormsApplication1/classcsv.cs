﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Threading;

namespace BDPROG_CSharp
{
    class classcsv
    {
        DataTable dt;
        String archivo;
        String delimitador;
        public double progreso=0;
        double registros;
        int j;
        int k;
        Thread proceso;
        

        public classcsv(DataTable tabla, String ruta, String simbolodelimitador)
        {
            dt = new DataTable();
            dt = tabla;
            archivo = ruta;
            delimitador = simbolodelimitador;
            progreso = 0;
       }
        public void creararchivo(string a)
        {
            
            proceso = new Thread(obtenprogreso);
            StreamWriter file;
            file = new StreamWriter(a);
            registros = dt.Rows.Count;
            proceso.Start();
            
            for (int i = 0; i <= dt.Columns.Count - 1; i++)
            {
               // System.Windows.Forms.MessageBox.Show(Convert.ToString(i));
                System.Windows.Forms.Application.DoEvents();
                
                file.Write(Convert.ToString(dt.Columns[i].ColumnName + delimitador));
            }
            file.WriteLine("");

            for (j = 0; j <=dt.Rows.Count-1; j++)
            {
               
                
                for (k = 0; k <= dt.Columns.Count - 1; k++ )
                {
                    file.Write(dt.Rows[j][k] + delimitador);
                }
                file.WriteLine("");

               
                
            }

           
            file.Close(); 
        
        }
        public void obtenprogreso()
        {

            while (progreso <=100)
            {
                Thread.Sleep(1);
                po();
            }
            
            
         }
        public double  po()
        {
            progreso = ((j + 1) / registros) * 100;
            return progreso;
        }
        
    }
}
