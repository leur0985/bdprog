﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace BDPROG_CSharp
{
    public partial class FormCsv : Form
    {
        Form1 principal = new Form1();
        Thread hilo;
        public DataTable tabla = new DataTable();
        public int valor;


        classcsv csv;

        public FormCsv()
        {

            InitializeComponent();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            
            String ruta;
            String simbolo;
            ruta = txtRuta.Text;
            simbolo = txtDelimitador.Text;
            hilo = new Thread(progreso);
            //this.progressBar1.Value = 0;
            csv = new classcsv(tabla, ruta, simbolo);
            hilo.Start();
            //timer1.Start();
            csv.creararchivo(ruta);
         }
        private void progreso()
        {
            while (csv.progreso<=100)
            {
                Thread.Sleep(1);
                progressBar1.Value = Convert.ToInt16(csv.progreso);
                label3.Text = Convert.ToString(csv.progreso);
            }
        }

        private void btExaminar_Click(object sender, EventArgs e)
        {
            Cuadros guardar = new Cuadros();
            txtRuta.Text = guardar.guarda("", "Guardar");
        }

        private void FormCsv_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          if (this.progressBar1.Value == 100)
            {
                timer1.Stop();

                MessageBox.Show("Archhivo de texto creado correctamente", "H E C H O", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

        }
    }
}