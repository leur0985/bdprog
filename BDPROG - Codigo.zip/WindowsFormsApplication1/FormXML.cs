﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BDPROG_CSharp
{
    public partial class FormXML : Form
    {
        string archivo;
        string nombretabla;
        public DataTable dt = new DataTable();

        public FormXML()
        {
            InitializeComponent();
        }


        private void btAceptar_Click(object sender, EventArgs e)
        {
            archivo=txtRuta.Text;
            nombretabla=txtNombreTabla.Text;
            classXML xml = new classXML(archivo,nombretabla,dt);
            xml.creararchivo();
            
            
        }

        private void btExaminar_Click(object sender, EventArgs e)
        {
            Cuadros guardar = new Cuadros();
            txtRuta.Text = guardar.guarda("", "Guardar");
        }

        
    }
}
