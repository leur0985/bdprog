﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XLinq;
using System.Data;


namespace BDPROG_CSharp
{
    class classXML
    {
        private String a;
        private String t;
        private DataTable dt;

        public classXML(string archivo, string nombretabla, DataTable tabla)
        {
            a = archivo;
            t = nombretabla;
            dt = tabla;
            
        }
        public void creararchivo()
        {
            XDocument documentoxml = new XDocument(new XDeclaration("1.0", "UTF-16", null));
            XElement nodoraiz = new XElement(t);
            documentoxml.Add(nodoraiz);
                        
            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                XElement registro = new XElement("registro");
                for (int k = 0; k <= dt.Columns.Count - 1; k++)
                {
                    
                    registro.Add(new XAttribute (dt.Columns[k].ColumnName, dt.Rows[i][k]));
                    
                  
                    
                }
                nodoraiz.Add(registro);
                
                
            }
            documentoxml.Save(a);


        }


        
    }
}
